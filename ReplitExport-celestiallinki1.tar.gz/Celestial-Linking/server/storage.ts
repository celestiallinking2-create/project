import {
  users,
  problems,
  runs,
  results,
  type User,
  type UpsertUser,
  type Problem,
  type InsertProblem,
  type Run,
  type InsertRun,
  type Result,
  type InsertResult,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  getProblems(userId: string): Promise<Problem[]>;
  getProblem(id: string): Promise<Problem | undefined>;
  createProblem(problem: InsertProblem): Promise<Problem>;
  updateProblem(id: string, problem: Partial<InsertProblem>): Promise<Problem | undefined>;
  deleteProblem(id: string): Promise<boolean>;
  
  getRuns(userId: string): Promise<Run[]>;
  getRun(id: string): Promise<Run | undefined>;
  createRun(run: InsertRun): Promise<Run>;
  updateRun(id: string, run: Partial<InsertRun>): Promise<Run | undefined>;
  deleteRun(id: string): Promise<boolean>;
  
  getResult(runId: string): Promise<Result | undefined>;
  createResult(result: InsertResult): Promise<Result>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getProblems(userId: string): Promise<Problem[]> {
    return await db
      .select()
      .from(problems)
      .where(eq(problems.userId, userId))
      .orderBy(desc(problems.createdAt));
  }

  async getProblem(id: string): Promise<Problem | undefined> {
    const [problem] = await db.select().from(problems).where(eq(problems.id, id));
    return problem;
  }

  async createProblem(problem: InsertProblem): Promise<Problem> {
    const [created] = await db.insert(problems).values(problem).returning();
    return created;
  }

  async updateProblem(id: string, problem: Partial<InsertProblem>): Promise<Problem | undefined> {
    const [updated] = await db
      .update(problems)
      .set({ ...problem, updatedAt: new Date() })
      .where(eq(problems.id, id))
      .returning();
    return updated;
  }

  async deleteProblem(id: string): Promise<boolean> {
    const result = await db.delete(problems).where(eq(problems.id, id));
    return true;
  }

  async getRuns(userId: string): Promise<Run[]> {
    return await db
      .select()
      .from(runs)
      .where(eq(runs.userId, userId))
      .orderBy(desc(runs.createdAt));
  }

  async getRun(id: string): Promise<Run | undefined> {
    const [run] = await db.select().from(runs).where(eq(runs.id, id));
    return run;
  }

  async createRun(run: InsertRun): Promise<Run> {
    const [created] = await db.insert(runs).values(run).returning();
    return created;
  }

  async updateRun(id: string, run: Partial<InsertRun>): Promise<Run | undefined> {
    const [updated] = await db
      .update(runs)
      .set(run)
      .where(eq(runs.id, id))
      .returning();
    return updated;
  }

  async deleteRun(id: string): Promise<boolean> {
    await db.delete(runs).where(eq(runs.id, id));
    return true;
  }

  async getResult(runId: string): Promise<Result | undefined> {
    const [result] = await db.select().from(results).where(eq(results.runId, runId));
    return result;
  }

  async createResult(result: InsertResult): Promise<Result> {
    const [created] = await db.insert(results).values(result).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
