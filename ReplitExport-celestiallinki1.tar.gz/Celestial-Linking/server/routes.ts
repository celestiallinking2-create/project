import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertRunSchema, insertProblemSchema } from "@shared/schema";
import { solveQuantumProblem } from "./quantumSolver";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);

  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/problems", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const problems = await storage.getProblems(userId);
      res.json(problems);
    } catch (error) {
      console.error("Error fetching problems:", error);
      res.status(500).json({ message: "Failed to fetch problems" });
    }
  });

  app.get("/api/problems/:id", isAuthenticated, async (req: any, res) => {
    try {
      const problem = await storage.getProblem(req.params.id);
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }
      if (problem.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(problem);
    } catch (error) {
      console.error("Error fetching problem:", error);
      res.status(500).json({ message: "Failed to fetch problem" });
    }
  });

  app.post("/api/problems", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validated = insertProblemSchema.parse({ ...req.body, userId });
      const problem = await storage.createProblem(validated);
      res.status(201).json(problem);
    } catch (error) {
      console.error("Error creating problem:", error);
      res.status(400).json({ message: "Invalid problem data" });
    }
  });

  app.delete("/api/problems/:id", isAuthenticated, async (req: any, res) => {
    try {
      const problem = await storage.getProblem(req.params.id);
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }
      if (problem.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Forbidden" });
      }
      await storage.deleteProblem(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting problem:", error);
      res.status(500).json({ message: "Failed to delete problem" });
    }
  });

  app.get("/api/runs", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const runs = await storage.getRuns(userId);
      res.json(runs);
    } catch (error) {
      console.error("Error fetching runs:", error);
      res.status(500).json({ message: "Failed to fetch runs" });
    }
  });

  app.get("/api/runs/:id", isAuthenticated, async (req: any, res) => {
    try {
      const run = await storage.getRun(req.params.id);
      if (!run) {
        return res.status(404).json({ message: "Run not found" });
      }
      if (run.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(run);
    } catch (error) {
      console.error("Error fetching run:", error);
      res.status(500).json({ message: "Failed to fetch run" });
    }
  });

  app.post("/api/runs", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const startTime = Date.now();
      
      const validated = insertRunSchema.parse({ 
        ...req.body, 
        userId,
        status: "running" 
      });
      
      const run = await storage.createRun(validated);

      const result = solveQuantumProblem(
        run.modelType,
        run.parameters as Record<string, any>,
        run.quality
      );

      const runtime = Date.now() - startTime;
      await storage.updateRun(run.id, { 
        status: "completed", 
        runtime,
        completedAt: new Date() 
      } as any);

      await storage.createResult({
        runId: run.id,
        eigenvalues: result.eigenvalues,
        eigenvectors: result.eigenvectors,
        probabilities: result.probabilities,
        wavefunctions: result.wavefunctions,
        summary: result.summary,
      });

      const updatedRun = await storage.getRun(run.id);
      res.status(201).json(updatedRun);
    } catch (error) {
      console.error("Error creating run:", error);
      res.status(400).json({ message: "Invalid run data" });
    }
  });

  app.delete("/api/runs/:id", isAuthenticated, async (req: any, res) => {
    try {
      const run = await storage.getRun(req.params.id);
      if (!run) {
        return res.status(404).json({ message: "Run not found" });
      }
      if (run.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Forbidden" });
      }
      await storage.deleteRun(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting run:", error);
      res.status(500).json({ message: "Failed to delete run" });
    }
  });

  app.get("/api/results/:runId", isAuthenticated, async (req: any, res) => {
    try {
      const run = await storage.getRun(req.params.runId);
      if (!run) {
        return res.status(404).json({ message: "Run not found" });
      }
      if (run.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Forbidden" });
      }
      const result = await storage.getResult(req.params.runId);
      if (!result) {
        return res.status(404).json({ message: "Result not found" });
      }
      res.json(result);
    } catch (error) {
      console.error("Error fetching result:", error);
      res.status(500).json({ message: "Failed to fetch result" });
    }
  });

  return httpServer;
}
