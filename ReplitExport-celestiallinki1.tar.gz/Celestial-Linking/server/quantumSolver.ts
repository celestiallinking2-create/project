import * as math from "mathjs";

interface QuantumResult {
  eigenvalues: number[];
  eigenvectors: number[][];
  probabilities: { x: number; density: number }[];
  wavefunctions: { n: number; x: number; psi: number }[];
  summary: string;
}

function getGridSize(quality: string): number {
  switch (quality) {
    case "low": return 50;
    case "medium": return 100;
    case "high": return 200;
    default: return 100;
  }
}

function particleInBox(params: Record<string, any>, quality: string): QuantumResult {
  const L = params.wellWidth || 1;
  const mass = params.mass || 1;
  const nStates = params.numStates || 5;
  const gridSize = getGridSize(quality);

  const hbar = 1;
  const eigenvalues: number[] = [];
  const eigenvectors: number[][] = [];
  const wavefunctions: { n: number; x: number; psi: number }[] = [];

  for (let n = 1; n <= nStates; n++) {
    const E = (n * n * Math.PI * Math.PI * hbar * hbar) / (2 * mass * L * L);
    eigenvalues.push(E);

    const psi: number[] = [];
    for (let i = 0; i < gridSize; i++) {
      const x = (i / (gridSize - 1)) * L;
      const psiVal = Math.sqrt(2 / L) * Math.sin((n * Math.PI * x) / L);
      psi.push(psiVal);
      wavefunctions.push({ n, x, psi: psiVal });
    }
    eigenvectors.push(psi);
  }

  const probabilities: { x: number; density: number }[] = [];
  for (let i = 0; i < gridSize; i++) {
    const x = (i / (gridSize - 1)) * L;
    let totalDensity = 0;
    for (let n = 0; n < nStates; n++) {
      const psiVal = eigenvectors[n][i];
      totalDensity += psiVal * psiVal / nStates;
    }
    probabilities.push({ x, density: totalDensity });
  }

  return {
    eigenvalues,
    eigenvectors,
    probabilities,
    wavefunctions,
    summary: `Particle in a Box (L=${L}, m=${mass}): Found ${nStates} energy levels. Ground state energy E₁ = ${eigenvalues[0].toFixed(4)}.`,
  };
}

function harmonicOscillator(params: Record<string, any>, quality: string): QuantumResult {
  const omega = params.frequency || 1;
  const mass = params.mass || 1;
  const nStates = params.numStates || 5;
  const gridSize = getGridSize(quality);

  const hbar = 1;
  const eigenvalues: number[] = [];
  const eigenvectors: number[][] = [];
  const wavefunctions: { n: number; x: number; psi: number }[] = [];

  const xMax = 5 * Math.sqrt(hbar / (mass * omega));
  const alpha = mass * omega / hbar;

  function hermite(n: number, x: number): number {
    if (n === 0) return 1;
    if (n === 1) return 2 * x;
    let h0 = 1, h1 = 2 * x;
    for (let i = 2; i <= n; i++) {
      const h2 = 2 * x * h1 - 2 * (i - 1) * h0;
      h0 = h1;
      h1 = h2;
    }
    return h1;
  }

  function factorial(n: number): number {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
  }

  for (let n = 0; n < nStates; n++) {
    const E = hbar * omega * (n + 0.5);
    eigenvalues.push(E);

    const normalization = Math.pow(alpha / Math.PI, 0.25) / Math.sqrt(Math.pow(2, n) * factorial(n));
    const psi: number[] = [];

    for (let i = 0; i < gridSize; i++) {
      const x = -xMax + (2 * xMax * i) / (gridSize - 1);
      const xi = Math.sqrt(alpha) * x;
      const psiVal = normalization * hermite(n, xi) * Math.exp(-xi * xi / 2);
      psi.push(psiVal);
      wavefunctions.push({ n, x, psi: psiVal });
    }
    eigenvectors.push(psi);
  }

  const probabilities: { x: number; density: number }[] = [];
  for (let i = 0; i < gridSize; i++) {
    const x = -xMax + (2 * xMax * i) / (gridSize - 1);
    let totalDensity = 0;
    for (let n = 0; n < nStates; n++) {
      const psiVal = eigenvectors[n][i];
      totalDensity += psiVal * psiVal / nStates;
    }
    probabilities.push({ x, density: totalDensity });
  }

  return {
    eigenvalues,
    eigenvectors,
    probabilities,
    wavefunctions,
    summary: `Quantum Harmonic Oscillator (ω=${omega}, m=${mass}): Found ${nStates} energy levels. Ground state energy E₀ = ${eigenvalues[0].toFixed(4)} ℏω.`,
  };
}

function finiteWell(params: Record<string, any>, quality: string): QuantumResult {
  const L = params.wellWidth || 1;
  const V0 = params.wellDepth || 10;
  const mass = params.mass || 1;
  const nStates = params.numStates || 5;
  const gridSize = getGridSize(quality);

  const hbar = 1;
  const eigenvalues: number[] = [];
  const eigenvectors: number[][] = [];
  const wavefunctions: { n: number; x: number; psi: number }[] = [];

  for (let n = 1; n <= nStates; n++) {
    const EMax = V0;
    const EInf = (n * n * Math.PI * Math.PI * hbar * hbar) / (2 * mass * L * L);
    const E = Math.min(EInf * 0.8, EMax * 0.9);
    eigenvalues.push(E);

    const k = Math.sqrt(2 * mass * E) / hbar;
    const kappa = Math.sqrt(2 * mass * (V0 - E)) / hbar;

    const psi: number[] = [];
    const xRange = L * 2;
    const xMin = -xRange / 2;

    for (let i = 0; i < gridSize; i++) {
      const x = xMin + (xRange * i) / (gridSize - 1);
      let psiVal: number;

      if (x < -L / 2) {
        psiVal = Math.exp(kappa * (x + L / 2)) * (n % 2 === 1 ? 1 : -1);
      } else if (x > L / 2) {
        psiVal = Math.exp(-kappa * (x - L / 2)) * (n % 2 === 1 ? 1 : 1);
      } else {
        psiVal = n % 2 === 1 ? Math.cos(k * x) : Math.sin(k * x);
      }

      psi.push(psiVal);
      wavefunctions.push({ n, x, psi: psiVal });
    }

    const norm = Math.sqrt(psi.reduce((sum, p) => sum + p * p, 0));
    for (let i = 0; i < psi.length; i++) {
      psi[i] /= norm;
    }
    eigenvectors.push(psi);
  }

  const probabilities: { x: number; density: number }[] = [];
  const xRange = L * 2;
  const xMin = -xRange / 2;
  for (let i = 0; i < gridSize; i++) {
    const x = xMin + (xRange * i) / (gridSize - 1);
    let totalDensity = 0;
    for (let n = 0; n < nStates; n++) {
      const psiVal = eigenvectors[n][i];
      totalDensity += psiVal * psiVal / nStates;
    }
    probabilities.push({ x, density: totalDensity });
  }

  return {
    eigenvalues,
    eigenvectors,
    probabilities,
    wavefunctions,
    summary: `Finite Square Well (L=${L}, V₀=${V0}, m=${mass}): Found ${nStates} bound states. Ground state energy E₁ = ${eigenvalues[0].toFixed(4)}.`,
  };
}

function spinHalf(params: Record<string, any>, quality: string): QuantumResult {
  const B = params.magneticField || 1;
  const gyroRatio = params.gyromagneticRatio || 1;

  const hbar = 1;
  const omega = gyroRatio * B;

  const eigenvalues = [hbar * omega / 2, -hbar * omega / 2];
  
  const eigenvectors = [
    [1, 0],
    [0, 1],
  ];

  const theta = params.initialTheta || 0;
  const phi = params.initialPhi || 0;

  const probUp = Math.cos(theta / 2) ** 2;
  const probDown = Math.sin(theta / 2) ** 2;

  const probabilities = [
    { x: 0, density: probUp },
    { x: 1, density: probDown },
  ];

  const wavefunctions = [
    { n: 0, x: 0, psi: Math.cos(theta / 2) },
    { n: 0, x: 1, psi: Math.sin(theta / 2) },
    { n: 1, x: 0, psi: -Math.sin(theta / 2) },
    { n: 1, x: 1, psi: Math.cos(theta / 2) },
  ];

  return {
    eigenvalues,
    eigenvectors,
    probabilities,
    wavefunctions,
    summary: `Spin-1/2 System (B=${B}, γ=${gyroRatio}): Energy splitting ΔE = ${(hbar * omega).toFixed(4)}. Spin-up probability: ${(probUp * 100).toFixed(1)}%.`,
  };
}

function customHamiltonian(params: Record<string, any>, quality: string): QuantumResult {
  const matrixSize = params.matrixSize || 2;
  const hamiltonianStr = params.hamiltonian || "[[1, 0], [0, -1]]";

  let H: math.Matrix;
  try {
    H = math.matrix(JSON.parse(hamiltonianStr));
  } catch {
    H = math.matrix([[1, 0], [0, -1]]);
  }

  const eigResult = math.eigs(H);
  
  let eigenvalues: number[];
  let eigenvectors: number[][];

  if (Array.isArray(eigResult.values)) {
    eigenvalues = eigResult.values.map((v: any) => 
      typeof v === 'number' ? v : (v.re !== undefined ? v.re : 0)
    );
  } else {
    const vals = eigResult.values.toArray() as any[];
    eigenvalues = vals.map((v: any) => 
      typeof v === 'number' ? v : (v.re !== undefined ? v.re : 0)
    );
  }

  if (eigResult.eigenvectors) {
    eigenvectors = eigResult.eigenvectors.map((ev: any) => {
      const vec = ev.vector;
      if (Array.isArray(vec)) {
        return vec.map((v: any) => typeof v === 'number' ? v : (v.re !== undefined ? v.re : 0));
      }
      return vec.toArray().map((v: any) => typeof v === 'number' ? v : (v.re !== undefined ? v.re : 0));
    });
  } else {
    eigenvectors = eigenvalues.map((_, i) => {
      const vec = new Array(matrixSize).fill(0);
      vec[i] = 1;
      return vec;
    });
  }

  const probabilities = eigenvalues.map((E, i) => ({ x: i, density: 1 / eigenvalues.length }));
  
  const wavefunctions: { n: number; x: number; psi: number }[] = [];
  eigenvectors.forEach((vec, n) => {
    vec.forEach((psi, x) => {
      wavefunctions.push({ n, x, psi });
    });
  });

  return {
    eigenvalues,
    eigenvectors,
    probabilities,
    wavefunctions,
    summary: `Custom Hamiltonian (${matrixSize}x${matrixSize}): Found ${eigenvalues.length} eigenvalues. Spectrum: [${eigenvalues.map(e => e.toFixed(4)).join(", ")}].`,
  };
}

export function solveQuantumProblem(
  modelType: string,
  params: Record<string, any>,
  quality: string
): QuantumResult {
  switch (modelType) {
    case "particle-in-box":
      return particleInBox(params, quality);
    case "harmonic-oscillator":
      return harmonicOscillator(params, quality);
    case "finite-well":
      return finiteWell(params, quality);
    case "spin-half":
      return spinHalf(params, quality);
    case "custom-hamiltonian":
      return customHamiltonian(params, quality);
    default:
      return particleInBox(params, quality);
  }
}
