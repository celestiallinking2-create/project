import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { useAuth } from "@/hooks/useAuth";
import { Navigation } from "@/components/Navigation";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import QuantumLibrary from "@/pages/QuantumLibrary";
import ModelDetail from "@/pages/ModelDetail";
import ManualSolver from "@/pages/ManualSolver";
import MyRuns from "@/pages/MyRuns";
import ResultView from "@/pages/ResultView";
import Help from "@/pages/Help";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-quantum-cyan border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {!isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/library" component={QuantumLibrary} />
          <Route path="/library/:id" component={ModelDetail} />
          <Route path="/solver" component={ManualSolver} />
          <Route path="/runs" component={MyRuns} />
          <Route path="/runs/:id" component={ResultView} />
          <Route path="/help" component={Help} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <>
      {(isAuthenticated || isLoading) && <Navigation />}
      <Router />
      <Toaster />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <AppContent />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
