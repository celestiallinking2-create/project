import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ChartProps {
  title: string;
  data: any[];
  className?: string;
}

export function EnergyLevelChart({ title, data, className = "" }: ChartProps) {
  return (
    <Card className={className}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} layout="vertical" margin={{ left: 20, right: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <YAxis 
              dataKey="level" 
              type="category" 
              stroke="hsl(var(--muted-foreground))" 
              fontSize={12}
              width={40}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                boxShadow: "var(--shadow-lg)",
              }}
              labelStyle={{ color: "hsl(var(--foreground))" }}
            />
            <Bar 
              dataKey="energy" 
              fill="hsl(261 80% 74%)" 
              radius={[0, 4, 4, 0]}
              name="Energy (eV)"
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function ProbabilityChart({ title, data, className = "" }: ChartProps) {
  return (
    <Card className={className}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data} margin={{ left: 0, right: 20 }}>
            <defs>
              <linearGradient id="probabilityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(187 100% 50%)" stopOpacity={0.4} />
                <stop offset="95%" stopColor="hsl(187 100% 50%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="x" 
              stroke="hsl(var(--muted-foreground))" 
              fontSize={12}
              label={{ value: "Position (nm)", position: "bottom", offset: -5 }}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))" 
              fontSize={12}
              label={{ value: "|ψ|²", angle: -90, position: "insideLeft" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                boxShadow: "var(--shadow-lg)",
              }}
            />
            <Area
              type="monotone"
              dataKey="probability"
              stroke="hsl(187 100% 50%)"
              strokeWidth={2}
              fill="url(#probabilityGradient)"
              name="Probability Density"
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function WavefunctionChart({ title, data, className = "" }: ChartProps) {
  return (
    <Card className={className}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data} margin={{ left: 0, right: 20 }}>
            <defs>
              <linearGradient id="wavefunctionGradient" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="hsl(187 100% 50%)" />
                <stop offset="100%" stopColor="hsl(261 80% 74%)" />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="x" 
              stroke="hsl(var(--muted-foreground))" 
              fontSize={12}
              label={{ value: "Position (nm)", position: "bottom", offset: -5 }}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))" 
              fontSize={12}
              label={{ value: "ψ(x)", angle: -90, position: "insideLeft" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                boxShadow: "var(--shadow-lg)",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="real"
              stroke="hsl(187 100% 50%)"
              strokeWidth={2}
              dot={false}
              name="Real Part"
            />
            <Line
              type="monotone"
              dataKey="imaginary"
              stroke="hsl(261 80% 74%)"
              strokeWidth={2}
              dot={false}
              name="Imaginary Part"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function generateSampleEnergyData(levels: number = 5) {
  return Array.from({ length: levels }, (_, i) => ({
    level: `n=${i + 1}`,
    energy: ((i + 1) ** 2) * 0.376,
  }));
}

export function generateSampleProbabilityData(points: number = 100, state: number = 1) {
  const L = 1;
  return Array.from({ length: points }, (_, i) => {
    const x = (i / (points - 1)) * L;
    const psi = Math.sqrt(2 / L) * Math.sin((state * Math.PI * x) / L);
    return {
      x: x.toFixed(3),
      probability: (psi ** 2).toFixed(4),
    };
  });
}

export function generateSampleWavefunctionData(points: number = 100, state: number = 1) {
  const L = 1;
  return Array.from({ length: points }, (_, i) => {
    const x = (i / (points - 1)) * L;
    const psi = Math.sqrt(2 / L) * Math.sin((state * Math.PI * x) / L);
    return {
      x: x.toFixed(3),
      real: psi.toFixed(4),
      imaginary: 0,
    };
  });
}
