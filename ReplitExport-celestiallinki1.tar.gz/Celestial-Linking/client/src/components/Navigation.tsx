import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Atom,
  Moon,
  Sun,
  Menu,
  X,
  Home,
  Library,
  Calculator,
  History,
  HelpCircle,
  LogOut,
  User,
} from "lucide-react";
import { useState } from "react";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/library", label: "Quantum Library", icon: Library },
  { href: "/solver", label: "Manual Solver", icon: Calculator },
  { href: "/runs", label: "My Runs", icon: History },
  { href: "/help", label: "Help", icon: HelpCircle },
];

export function Navigation() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 bg-deep-space-gradient border-b border-white/10 backdrop-blur-md">
      <div className="h-full max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-3 group" data-testid="link-home-logo">
          <div className="relative">
            <Atom className="w-8 h-8 text-quantum-cyan transition-transform group-hover:rotate-180 duration-700" />
            <div className="absolute inset-0 blur-md bg-quantum-cyan/30 rounded-full" />
          </div>
          <span className="text-lg font-semibold text-white hidden sm:block">
            Celestial Linking
          </span>
        </Link>

        {isAuthenticated && (
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = location === item.href || 
                (item.href !== "/" && location.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`text-white/80 hover:text-white hover:bg-white/10 ${
                      isActive ? "bg-white/10 text-white" : ""
                    }`}
                    data-testid={`link-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <item.icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </nav>
        )}

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="text-white/80 hover:text-white hover:bg-white/10"
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? (
              <Sun className="w-5 h-5" />
            ) : (
              <Moon className="w-5 h-5" />
            )}
          </Button>

          {isLoading ? (
            <div className="w-9 h-9 rounded-full bg-white/10 animate-pulse" />
          ) : isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full p-0 h-9 w-9"
                  data-testid="button-user-menu"
                >
                  <Avatar className="h-9 w-9 border-2 border-quantum-cyan/50">
                    <AvatarImage
                      src={user.profileImageUrl ?? undefined}
                      alt={user.firstName ?? "User"}
                      className="object-cover"
                    />
                    <AvatarFallback className="bg-quantum-cyan/20 text-quantum-cyan text-sm font-medium">
                      {getInitials()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-3 py-2 text-sm">
                  <p className="font-medium" data-testid="text-user-name">
                    {user.firstName ? `${user.firstName} ${user.lastName ?? ""}`.trim() : "User"}
                  </p>
                  <p className="text-muted-foreground text-xs truncate" data-testid="text-user-email">
                    {user.email}
                  </p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <a href="/api/logout" className="flex items-center gap-2 cursor-pointer" data-testid="link-logout">
                    <LogOut className="w-4 h-4" />
                    Log out
                  </a>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              asChild
              className="bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90 font-medium"
              data-testid="button-login"
            >
              <a href="/api/login">Log in</a>
            </Button>
          )}

          {isAuthenticated && (
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-white/80 hover:text-white hover:bg-white/10"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          )}
        </div>
      </div>

      {mobileMenuOpen && isAuthenticated && (
        <nav className="lg:hidden absolute top-16 left-0 right-0 bg-deep-space-gradient border-b border-white/10 p-4">
          <div className="flex flex-col gap-1">
            {navItems.map((item) => {
              const isActive = location === item.href || 
                (item.href !== "/" && location.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href} onClick={() => setMobileMenuOpen(false)}>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start text-white/80 hover:text-white hover:bg-white/10 ${
                      isActive ? "bg-white/10 text-white" : ""
                    }`}
                    data-testid={`link-mobile-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <item.icon className="w-4 h-4 mr-3" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </header>
  );
}
