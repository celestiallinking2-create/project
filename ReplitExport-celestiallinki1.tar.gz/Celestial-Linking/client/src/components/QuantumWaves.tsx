interface QuantumWavesProps {
  className?: string;
  variant?: "hero" | "subtle";
}

export function QuantumWaves({ className = "", variant = "subtle" }: QuantumWavesProps) {
  const opacity = variant === "hero" ? "0.15" : "0.05";
  
  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      <svg
        className="absolute w-full h-full animate-quantum-wave"
        viewBox="0 0 1200 600"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <linearGradient id="waveGradient1" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="hsl(187 100% 50%)" stopOpacity={opacity} />
            <stop offset="50%" stopColor="hsl(261 80% 74%)" stopOpacity={opacity} />
            <stop offset="100%" stopColor="hsl(187 100% 50%)" stopOpacity={opacity} />
          </linearGradient>
          <linearGradient id="waveGradient2" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="hsl(261 80% 74%)" stopOpacity={opacity} />
            <stop offset="50%" stopColor="hsl(187 100% 50%)" stopOpacity={opacity} />
            <stop offset="100%" stopColor="hsl(261 80% 74%)" stopOpacity={opacity} />
          </linearGradient>
        </defs>
        
        <path
          d="M0,300 Q150,200 300,300 T600,300 T900,300 T1200,300 L1200,600 L0,600 Z"
          fill="url(#waveGradient1)"
        />
        <path
          d="M0,350 Q150,250 300,350 T600,350 T900,350 T1200,350 L1200,600 L0,600 Z"
          fill="url(#waveGradient2)"
          style={{ animationDelay: "-3s" }}
        />
        <path
          d="M0,400 Q150,300 300,400 T600,400 T900,400 T1200,400 L1200,600 L0,600 Z"
          fill="url(#waveGradient1)"
          style={{ animationDelay: "-6s" }}
        />
      </svg>
    </div>
  );
}

export function ParticleField({ className = "" }: { className?: string }) {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    size: Math.random() * 4 + 2,
    delay: Math.random() * 4,
    duration: Math.random() * 3 + 3,
    color: i % 2 === 0 ? "bg-quantum-cyan" : "bg-soft-violet",
  }));

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      {particles.map((particle) => (
        <div
          key={particle.id}
          className={`absolute rounded-full ${particle.color} opacity-40 animate-particle`}
          style={{
            left: particle.left,
            top: particle.top,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            animationDelay: `${particle.delay}s`,
            animationDuration: `${particle.duration}s`,
          }}
        />
      ))}
    </div>
  );
}
