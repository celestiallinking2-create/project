import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Atom, Waves, Square, RotateCcw, Grid3X3 } from "lucide-react";
import { Link } from "wouter";

export interface QuantumModel {
  id: string;
  title: string;
  description: string;
  icon: "atom" | "waves" | "square" | "spin" | "grid";
  difficulty: "beginner" | "intermediate" | "advanced";
  category: "basic" | "many-body";
}

const iconMap = {
  atom: Atom,
  waves: Waves,
  square: Square,
  spin: RotateCcw,
  grid: Grid3X3,
};

const difficultyColors = {
  beginner: "bg-green-500/10 text-green-600 dark:text-green-400",
  intermediate: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
  advanced: "bg-red-500/10 text-red-600 dark:text-red-400",
};

export function ModelCard({ model }: { model: QuantumModel }) {
  const Icon = iconMap[model.icon];

  return (
    <Card 
      className="group relative overflow-visible transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
      data-testid={`card-model-${model.id}`}
    >
      <div className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
        <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-quantum-cyan/20 to-soft-violet/20 blur-xl" />
      </div>
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="p-3 rounded-lg bg-gradient-to-br from-quantum-cyan/10 to-soft-violet/10">
            <Icon className="w-6 h-6 text-quantum-cyan" />
          </div>
          <Badge 
            variant="secondary" 
            className={`text-xs ${difficultyColors[model.difficulty]}`}
          >
            {model.difficulty}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pb-4">
        <h3 className="font-semibold text-lg mb-2" data-testid={`text-model-title-${model.id}`}>
          {model.title}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {model.description}
        </p>
      </CardContent>
      
      <CardFooter>
        <Link href={`/library/${model.id}`} className="w-full">
          <Button 
            className="w-full group/btn bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90"
            data-testid={`button-explore-${model.id}`}
          >
            Explore Model
            <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover/btn:translate-x-1" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}

export const quantumModels: QuantumModel[] = [
  {
    id: "particle-in-box",
    title: "Particle in a Box",
    description: "Study the quantum mechanical behavior of a particle confined in an infinite potential well with discrete energy levels.",
    icon: "square",
    difficulty: "beginner",
    category: "basic",
  },
  {
    id: "harmonic-oscillator",
    title: "Harmonic Oscillator",
    description: "Explore the quantum harmonic oscillator with equally spaced energy levels and Hermite polynomial wavefunctions.",
    icon: "waves",
    difficulty: "beginner",
    category: "basic",
  },
  {
    id: "finite-well",
    title: "Finite Potential Well",
    description: "Analyze bound states in a finite potential well with tunneling effects and exponential decay outside the well.",
    icon: "square",
    difficulty: "intermediate",
    category: "basic",
  },
  {
    id: "spin-half",
    title: "Spin-1/2 Systems",
    description: "Investigate two-level quantum systems with Pauli matrices and understand quantum superposition and measurement.",
    icon: "spin",
    difficulty: "intermediate",
    category: "basic",
  },
];
