import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Atom,
  Plus,
  Eye,
  Trash2,
  ArrowUpDown,
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Run } from "@shared/schema";

type StatusFilter = "all" | "completed" | "running" | "pending" | "failed";

const statusIcons = {
  completed: CheckCircle2,
  running: Loader2,
  pending: Clock,
  failed: XCircle,
};

const statusColors = {
  completed: "bg-green-500/10 text-green-600 dark:text-green-400",
  running: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  pending: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
  failed: "bg-red-500/10 text-red-600 dark:text-red-400",
};

export default function MyRuns() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  const { data: runs, isLoading } = useQuery<Run[]>({
    queryKey: ["/api/runs"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/runs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/runs"] });
      toast({
        title: "Run Deleted",
        description: "The run has been removed from your history.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete run.",
        variant: "destructive",
      });
    },
  });

  const filteredRuns = (runs || [])
    .filter((run) => {
      const matchesSearch = run.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "all" || run.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      const dateA = new Date(a.createdAt || 0).getTime();
      const dateB = new Date(b.createdAt || 0).getTime();
      return sortOrder === "desc" ? dateB - dateA : dateA - dateB;
    });

  const formatDate = (date: Date | string | null) => {
    if (!date) return "—";
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="min-h-screen pt-16">
      <div className="bg-card/50 border-b py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold mb-1">My Runs</h1>
              <p className="text-muted-foreground">
                View and manage your quantum solver runs
              </p>
            </div>
            <Link href="/library">
              <Button data-testid="button-new-run">
                <Plus className="w-4 h-4 mr-2" />
                New Run
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search runs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-runs"
            />
          </div>
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
            <SelectTrigger className="w-[150px]" data-testid="select-status-filter">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="running">Running</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setSortOrder(sortOrder === "desc" ? "asc" : "desc")}
            data-testid="button-sort-order"
          >
            <ArrowUpDown className="w-4 h-4" />
          </Button>
        </div>

        {isLoading ? (
          <Card>
            <CardContent className="py-8">
              <div className="flex items-center justify-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                <span className="text-muted-foreground">Loading runs...</span>
              </div>
            </CardContent>
          </Card>
        ) : filteredRuns.length > 0 ? (
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-deep-space-gradient">
                    <TableHead className="text-white">Problem</TableHead>
                    <TableHead className="text-white">Model</TableHead>
                    <TableHead className="text-white">Status</TableHead>
                    <TableHead className="text-white">Runtime</TableHead>
                    <TableHead className="text-white">Date</TableHead>
                    <TableHead className="text-white text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRuns.map((run, index) => {
                    const StatusIcon = statusIcons[run.status as keyof typeof statusIcons] || Clock;
                    const statusColor = statusColors[run.status as keyof typeof statusColors] || statusColors.pending;
                    
                    return (
                      <TableRow 
                        key={run.id} 
                        className={index % 2 === 0 ? "bg-background" : "bg-muted/30"}
                        data-testid={`row-run-${run.id}`}
                      >
                        <TableCell className="font-medium">{run.title}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {run.modelType.replace(/-/g, " ")}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={statusColor}>
                            <StatusIcon className={`w-3 h-3 mr-1 ${run.status === "running" ? "animate-spin" : ""}`} />
                            {run.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {run.runtime ? `${run.runtime}ms` : "—"}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(run.createdAt)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Link href={`/runs/${run.id}`}>
                              <Button variant="ghost" size="icon" data-testid={`button-view-${run.id}`}>
                                <Eye className="w-4 h-4" />
                              </Button>
                            </Link>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteMutation.mutate(run.id)}
                              disabled={deleteMutation.isPending}
                              data-testid={`button-delete-${run.id}`}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </Card>
        ) : (
          <Card className="border-dashed">
            <CardContent className="py-16 text-center">
              <div className="p-4 rounded-full bg-muted w-fit mx-auto mb-4">
                <Atom className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium mb-2">No runs found</h3>
              <p className="text-sm text-muted-foreground mb-6">
                {searchQuery || statusFilter !== "all"
                  ? "Try adjusting your search or filters."
                  : "Start your first quantum calculation to see it here."}
              </p>
              <Link href="/library">
                <Button data-testid="button-start-first-run">
                  <Plus className="w-4 h-4 mr-2" />
                  Start First Run
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
