import { useState } from "react";
import { useParams, Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  ChevronLeft,
  Play,
  Atom,
  Waves,
  Square,
  RotateCcw,
  Grid3X3,
  Info,
  Loader2,
} from "lucide-react";
import { quantumModels } from "@/components/ModelCard";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

const iconMap = {
  atom: Atom,
  waves: Waves,
  square: Square,
  spin: RotateCcw,
  grid: Grid3X3,
};

interface ModelParams {
  particleInBox: { wellWidth: number; mass: number; states: number };
  harmonicOscillator: { frequency: number; mass: number; states: number };
  finiteWell: { wellWidth: number; wellDepth: number; mass: number; states: number };
  spinHalf: { magneticField: number; };
}

const defaultParams: Record<string, any> = {
  "particle-in-box": { wellWidth: 1, mass: 1, states: 5 },
  "harmonic-oscillator": { frequency: 1, mass: 1, states: 5 },
  "finite-well": { wellWidth: 1, wellDepth: 10, mass: 1, states: 5 },
  "spin-half": { magneticField: 1 },
};

const paramLabels: Record<string, Record<string, { label: string; unit: string; min: number; max: number; step: number }>> = {
  "particle-in-box": {
    wellWidth: { label: "Well Width", unit: "nm", min: 0.1, max: 10, step: 0.1 },
    mass: { label: "Particle Mass", unit: "m₀", min: 0.1, max: 10, step: 0.1 },
    states: { label: "Energy States", unit: "", min: 1, max: 20, step: 1 },
  },
  "harmonic-oscillator": {
    frequency: { label: "Angular Frequency", unit: "THz", min: 0.1, max: 10, step: 0.1 },
    mass: { label: "Particle Mass", unit: "m₀", min: 0.1, max: 10, step: 0.1 },
    states: { label: "Energy States", unit: "", min: 1, max: 20, step: 1 },
  },
  "finite-well": {
    wellWidth: { label: "Well Width", unit: "nm", min: 0.1, max: 10, step: 0.1 },
    wellDepth: { label: "Well Depth", unit: "eV", min: 1, max: 100, step: 1 },
    mass: { label: "Particle Mass", unit: "m₀", min: 0.1, max: 10, step: 0.1 },
    states: { label: "Energy States", unit: "", min: 1, max: 20, step: 1 },
  },
  "spin-half": {
    magneticField: { label: "Magnetic Field", unit: "T", min: 0.1, max: 10, step: 0.1 },
  },
};

export default function ModelDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const model = quantumModels.find((m) => m.id === id);
  const [params, setParams] = useState<Record<string, number>>(
    defaultParams[id || ""] || {}
  );
  const [quality, setQuality] = useState("medium");
  const [title, setTitle] = useState(model?.title || "Quantum Problem");

  const runMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/runs", {
        title,
        modelType: id,
        parameters: params,
        quality,
      });
      return response;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/runs"] });
      toast({
        title: "Solver Started",
        description: "Your quantum problem is being solved.",
      });
      navigate(`/runs/${data.id}`);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to start solver. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (!model) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Model Not Found</h2>
            <p className="text-muted-foreground mb-4">
              The quantum model you're looking for doesn't exist.
            </p>
            <Link href="/library">
              <Button>Back to Library</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const Icon = iconMap[model.icon];
  const modelParams = paramLabels[id || ""] || {};

  return (
    <div className="min-h-screen pt-16">
      <div className="bg-card/50 border-b py-4 px-6">
        <div className="max-w-7xl mx-auto">
          <Link href="/library">
            <Button variant="ghost" size="sm" className="mb-4" data-testid="button-back-to-library">
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back to Library
            </Button>
          </Link>
          <div className="flex items-start gap-4 flex-wrap">
            <div className="p-4 rounded-xl bg-gradient-to-br from-quantum-cyan/20 to-soft-violet/20">
              <Icon className="w-8 h-8 text-quantum-cyan" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2 flex-wrap">
                <h1 className="text-2xl font-semibold">{model.title}</h1>
                <Badge variant="secondary">{model.difficulty}</Badge>
              </div>
              <p className="text-muted-foreground">{model.description}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Problem Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Problem Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter a title for this problem"
                    data-testid="input-problem-title"
                  />
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-sm">Model Parameters</h4>
                  {Object.entries(modelParams).map(([key, config]) => (
                    <div key={key} className="space-y-2">
                      <Label htmlFor={key}>
                        {config.label}
                        {config.unit && (
                          <span className="text-muted-foreground ml-1">
                            ({config.unit})
                          </span>
                        )}
                      </Label>
                      <Input
                        id={key}
                        type="number"
                        value={params[key] || config.min}
                        onChange={(e) =>
                          setParams((p) => ({
                            ...p,
                            [key]: parseFloat(e.target.value),
                          }))
                        }
                        min={config.min}
                        max={config.max}
                        step={config.step}
                        data-testid={`input-param-${key}`}
                      />
                    </div>
                  ))}
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-sm">Solver Quality</h4>
                  <RadioGroup
                    value={quality}
                    onValueChange={setQuality}
                    className="flex flex-col gap-3"
                  >
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="basic" id="basic" />
                      <Label htmlFor="basic" className="cursor-pointer">
                        <span className="font-medium">Basic</span>
                        <span className="text-muted-foreground text-sm ml-2">
                          Fast computation, lower precision
                        </span>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="cursor-pointer">
                        <span className="font-medium">Medium</span>
                        <span className="text-muted-foreground text-sm ml-2">
                          Balanced speed and accuracy
                        </span>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="high" id="high" />
                      <Label htmlFor="high" className="cursor-pointer">
                        <span className="font-medium">High</span>
                        <span className="text-muted-foreground text-sm ml-2">
                          Maximum precision, slower
                        </span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            <Button
              size="lg"
              className="w-full bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90"
              onClick={() => runMutation.mutate()}
              disabled={runMutation.isPending}
              data-testid="button-run-solver"
            >
              {runMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Starting Solver...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" />
                  Run Solver
                </>
              )}
            </Button>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  About This Model
                </CardTitle>
              </CardHeader>
              <CardContent className="prose prose-sm dark:prose-invert max-w-none">
                {id === "particle-in-box" && (
                  <>
                    <p>
                      The infinite square well (particle in a box) is one of the
                      simplest quantum mechanical systems. A particle is confined
                      to a one-dimensional box with infinitely high walls.
                    </p>
                    <h4>Key Features:</h4>
                    <ul>
                      <li>Discrete energy levels: E_n = n²π²ℏ²/(2mL²)</li>
                      <li>Sinusoidal wavefunctions within the box</li>
                      <li>Zero probability at the walls</li>
                      <li>Quantized momentum states</li>
                    </ul>
                  </>
                )}
                {id === "harmonic-oscillator" && (
                  <>
                    <p>
                      The quantum harmonic oscillator describes a particle subject
                      to a quadratic potential, modeling molecular vibrations and
                      many physical systems.
                    </p>
                    <h4>Key Features:</h4>
                    <ul>
                      <li>Equally spaced energy levels: E_n = ℏω(n + 1/2)</li>
                      <li>Zero-point energy at n=0</li>
                      <li>Hermite polynomial wavefunctions</li>
                      <li>Gaussian envelope for probability density</li>
                    </ul>
                  </>
                )}
                {id === "finite-well" && (
                  <>
                    <p>
                      The finite potential well allows for more realistic modeling
                      of bound states with tunneling effects and evanescent waves.
                    </p>
                    <h4>Key Features:</h4>
                    <ul>
                      <li>Finite number of bound states</li>
                      <li>Exponential decay outside the well</li>
                      <li>Quantum tunneling phenomena</li>
                      <li>Transcendental energy equations</li>
                    </ul>
                  </>
                )}
                {id === "spin-half" && (
                  <>
                    <p>
                      Spin-1/2 systems are fundamental two-level quantum systems
                      described by Pauli matrices, forming the basis for quantum
                      computing qubits.
                    </p>
                    <h4>Key Features:</h4>
                    <ul>
                      <li>Two-dimensional Hilbert space</li>
                      <li>Pauli matrices: σ_x, σ_y, σ_z</li>
                      <li>Zeeman splitting in magnetic fields</li>
                      <li>Bloch sphere representation</li>
                    </ul>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Expected Outputs</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-quantum-cyan" />
                    Eigenvalues (energy levels)
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-soft-violet" />
                    Eigenvectors (quantum states)
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    Probability density plots
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-amber-500" />
                    Wavefunction visualizations
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
