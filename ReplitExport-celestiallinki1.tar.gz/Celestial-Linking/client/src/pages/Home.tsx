import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QuantumWaves } from "@/components/QuantumWaves";
import {
  Plus,
  Calculator,
  Library,
  Folder,
  ArrowRight,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Atom,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Run } from "@shared/schema";

const quickActions = [
  {
    href: "/library",
    icon: Plus,
    title: "New Quantum Problem",
    description: "Start with a predefined model",
    color: "from-quantum-cyan/20 to-quantum-cyan/5",
    iconColor: "text-quantum-cyan",
  },
  {
    href: "/solver",
    icon: Calculator,
    title: "Manual Equation Solver",
    description: "Input custom equations",
    color: "from-soft-violet/20 to-soft-violet/5",
    iconColor: "text-soft-violet",
  },
  {
    href: "/library",
    icon: Library,
    title: "Quantum Library",
    description: "Explore quantum models",
    color: "from-green-500/20 to-green-500/5",
    iconColor: "text-green-500",
  },
  {
    href: "/runs",
    icon: Folder,
    title: "My Saved Work",
    description: "View previous runs",
    color: "from-amber-500/20 to-amber-500/5",
    iconColor: "text-amber-500",
  },
];

const statusIcons = {
  completed: CheckCircle2,
  running: Loader2,
  pending: Clock,
  failed: XCircle,
};

const statusColors = {
  completed: "bg-green-500/10 text-green-600 dark:text-green-400",
  running: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  pending: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
  failed: "bg-red-500/10 text-red-600 dark:text-red-400",
};

export default function Home() {
  const { user } = useAuth();
  
  const { data: recentRuns, isLoading } = useQuery<Run[]>({
    queryKey: ["/api/runs", { limit: 5 }],
  });

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  return (
    <div className="min-h-screen pt-16">
      <section className="relative py-12 bg-deep-space-gradient overflow-hidden">
        <QuantumWaves variant="hero" />
        <div className="relative z-10 max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold text-white mb-2">
                {greeting()}, {user?.firstName || "Explorer"}
              </h1>
              <p className="text-white/70">
                Continue your quantum journey or start a new exploration.
              </p>
            </div>
            <Link href="/library">
              <Button 
                className="bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90"
                data-testid="button-new-problem"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Quantum Problem
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-xl font-semibold mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Link key={index} href={action.href}>
                <Card 
                  className="h-full group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                  data-testid={`card-quick-action-${index}`}
                >
                  <CardContent className="p-5">
                    <div className={`p-3 rounded-lg bg-gradient-to-br ${action.color} w-fit mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <action.icon className={`w-5 h-5 ${action.iconColor}`} />
                    </div>
                    <h3 className="font-medium mb-1">{action.title}</h3>
                    <p className="text-sm text-muted-foreground">{action.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 px-6 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
            <h2 className="text-xl font-semibold">Recent Runs</h2>
            <Link href="/runs">
              <Button variant="outline" size="sm" data-testid="button-view-all-runs">
                View All
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-5">
                    <div className="h-4 bg-muted rounded w-3/4 mb-3" />
                    <div className="h-3 bg-muted rounded w-1/2 mb-4" />
                    <div className="flex gap-2">
                      <div className="h-5 bg-muted rounded w-16" />
                      <div className="h-5 bg-muted rounded w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : recentRuns && recentRuns.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentRuns.map((run) => {
                const StatusIcon = statusIcons[run.status as keyof typeof statusIcons] || Clock;
                const statusColor = statusColors[run.status as keyof typeof statusColors] || statusColors.pending;
                
                return (
                  <Link key={run.id} href={`/runs/${run.id}`}>
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:shadow-md"
                      data-testid={`card-run-${run.id}`}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium truncate group-hover:text-quantum-cyan transition-colors">
                              {run.title}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {run.modelType.replace(/-/g, " ")}
                            </p>
                          </div>
                          <Badge variant="secondary" className={statusColor}>
                            <StatusIcon className={`w-3 h-3 mr-1 ${run.status === "running" ? "animate-spin" : ""}`} />
                            {run.status}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {run.runtime ? `${run.runtime}ms` : "—"}
                          </span>
                          <span>
                            {run.createdAt ? new Date(run.createdAt).toLocaleDateString() : "—"}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          ) : (
            <Card className="border-dashed">
              <CardContent className="py-12 text-center">
                <div className="p-4 rounded-full bg-muted w-fit mx-auto mb-4">
                  <Atom className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-medium mb-2">No runs yet</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Start your first quantum calculation to see it here.
                </p>
                <Link href="/library">
                  <Button data-testid="button-start-first-problem">
                    <Plus className="w-4 h-4 mr-2" />
                    Start First Problem
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-xl font-semibold mb-6">Platform Capabilities</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-quantum-cyan/10">
                    <Calculator className="w-4 h-4 text-quantum-cyan" />
                  </div>
                  Solver Accuracy
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Choose from Basic, Medium, or High quality settings to balance 
                  speed and precision for your calculations.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-soft-violet/10">
                    <Library className="w-4 h-4 text-soft-violet" />
                  </div>
                  Quantum Models
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Explore particle-in-a-box, harmonic oscillators, finite wells, 
                  and spin systems with adjustable parameters.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-green-500/10">
                    <Folder className="w-4 h-4 text-green-500" />
                  </div>
                  Data Persistence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  All your problems, runs, and results are automatically saved 
                  to your account for future reference.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
