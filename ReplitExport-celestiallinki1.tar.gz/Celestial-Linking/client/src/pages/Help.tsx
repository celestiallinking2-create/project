import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  BookOpen,
  Calculator,
  LineChart,
  Save,
  HelpCircle,
  ChevronRight,
  Atom,
} from "lucide-react";

const guides = [
  {
    id: "getting-started",
    icon: BookOpen,
    title: "Getting Started",
    description: "Learn the basics of using Celestial Linking",
    content: `
## Welcome to Celestial Linking

Celestial Linking is your gateway to exploring quantum mechanics through interactive simulations and calculations.

### Your First Quantum Problem

1. **Choose a Model**: Navigate to the Quantum Library and select a model that interests you, like the Particle in a Box.

2. **Configure Parameters**: Adjust the physical parameters such as well width, particle mass, and the number of energy states to compute.

3. **Run the Solver**: Click "Run Solver" to compute the eigenvalues and eigenvectors of your quantum system.

4. **Analyze Results**: View energy level diagrams, probability distributions, and wavefunction plots.

### Dashboard Overview

Your home dashboard shows:
- Quick actions for common tasks
- Recent solver runs
- Platform capabilities overview
    `,
  },
  {
    id: "manual-solver",
    icon: Calculator,
    title: "Manual Equation Solver",
    description: "How to input custom Hamiltonians and equations",
    content: `
## Using the Manual Solver

The Manual Equation Solver allows you to solve custom quantum problems beyond our predefined models.

### Matrix Input

Enter your Hamiltonian as a square matrix:

\`\`\`
1  0  0.5
0  2  0
0.5 0  3
\`\`\`

- Separate values with spaces or commas
- Each row on a new line
- Matrix must be square (NxN)

### Supported Calculations

- **Eigenvalue decomposition**: Find energy levels
- **Eigenvector computation**: Get quantum states
- **Probability distributions**: Calculate |ψ|²

### Quality Settings

- **Basic**: Fast computation, good for exploration
- **Medium**: Balanced speed and precision
- **High**: Maximum accuracy for research
    `,
  },
  {
    id: "understanding-plots",
    icon: LineChart,
    title: "Understanding Plots",
    description: "How to read and interpret quantum visualizations",
    content: `
## Interpreting Quantum Visualizations

### Energy Level Diagrams

Horizontal bar charts showing discrete energy eigenvalues:
- Each bar represents an energy state
- Height/length corresponds to energy value
- Spacing reveals energy quantization

### Probability Density |ψ|²

Area charts showing where particles are likely to be found:
- Higher values = higher probability
- Area under curve = 1 (normalized)
- Nodes show zero probability points

### Wavefunctions ψ(x)

Line plots showing quantum state amplitudes:
- Real part (solid line)
- Imaginary part (dashed line)
- Oscillations indicate particle wavelength

### Tips for Analysis

1. Compare energy level spacing
2. Count nodes in wavefunctions
3. Observe probability maxima/minima
    `,
  },
  {
    id: "saving-work",
    icon: Save,
    title: "Saving Your Work",
    description: "How data persistence works",
    content: `
## Persistent Workspace

All your work is automatically saved to your account.

### What Gets Saved

- **Problems**: Custom configurations you create
- **Runs**: Every solver execution with parameters
- **Results**: Computed eigenvalues, eigenvectors, and plots

### Accessing Saved Work

1. Go to "My Runs" from the navigation
2. Filter by status (Completed, Running, Failed)
3. Search by problem name
4. Click any run to view full results

### Exporting Data

Results can be exported in two formats:
- **CSV**: Spreadsheet-compatible eigenvalue tables
- **JSON**: Complete data including all computed values

### Data Management

- Runs are stored indefinitely
- Delete unwanted runs from the My Runs page
- All data is synced across devices
    `,
  },
];

const faqs = [
  {
    question: "What quantum models are available?",
    answer: "We currently support Particle in a Box, Harmonic Oscillator, Finite Potential Well, and Spin-1/2 Systems. More models including spin chains and Hubbard models are coming soon.",
  },
  {
    question: "How accurate are the calculations?",
    answer: "Our solvers use industry-standard numerical methods. High quality mode provides precision suitable for research, while Basic mode is great for quick exploration.",
  },
  {
    question: "Can I input custom Hamiltonians?",
    answer: "Yes! The Manual Equation Solver accepts custom Hamiltonian matrices. Enter your matrix with values separated by spaces or commas, with each row on a new line.",
  },
  {
    question: "Is my data secure?",
    answer: "Yes, all data is encrypted in transit and at rest. Your calculations and results are private to your account and not shared with anyone.",
  },
  {
    question: "What are the system requirements?",
    answer: "Celestial Linking runs entirely in your browser. Any modern browser (Chrome, Firefox, Safari, Edge) on desktop, tablet, or laptop will work.",
  },
  {
    question: "How long do calculations take?",
    answer: "Most calculations complete in under a second. Larger matrices or high-quality mode may take a few seconds. Complex many-body problems can take longer.",
  },
];

export default function Help() {
  const [selectedGuide, setSelectedGuide] = useState<string | null>(null);

  const activeGuide = guides.find((g) => g.id === selectedGuide);

  return (
    <div className="min-h-screen pt-16">
      <div className="bg-card/50 border-b py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-quantum-cyan/20 to-soft-violet/20">
              <HelpCircle className="w-6 h-6 text-quantum-cyan" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold">Help & Tutorials</h1>
              <p className="text-muted-foreground">
                Learn how to use Celestial Linking effectively
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-4">
            <h2 className="font-semibold text-lg mb-4">Guides</h2>
            {guides.map((guide) => (
              <Card
                key={guide.id}
                className={`cursor-pointer transition-all ${
                  selectedGuide === guide.id
                    ? "ring-2 ring-quantum-cyan"
                    : "hover:shadow-md"
                }`}
                onClick={() => setSelectedGuide(guide.id)}
                data-testid={`card-guide-${guide.id}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-quantum-cyan/10">
                      <guide.icon className="w-4 h-4 text-quantum-cyan" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm">{guide.title}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-1">
                        {guide.description}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="lg:col-span-2">
            {activeGuide ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-lg bg-quantum-cyan/10">
                      <activeGuide.icon className="w-5 h-5 text-quantum-cyan" />
                    </div>
                    <CardTitle>{activeGuide.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    {activeGuide.content.split("\n").map((line, i) => {
                      if (line.startsWith("## ")) {
                        return <h2 key={i} className="text-xl font-semibold mt-6 mb-3">{line.slice(3)}</h2>;
                      }
                      if (line.startsWith("### ")) {
                        return <h3 key={i} className="text-lg font-medium mt-4 mb-2">{line.slice(4)}</h3>;
                      }
                      if (line.startsWith("- ")) {
                        return <li key={i} className="ml-4">{line.slice(2)}</li>;
                      }
                      if (line.match(/^\d+\./)) {
                        return <li key={i} className="ml-4">{line}</li>;
                      }
                      if (line.startsWith("```")) {
                        return null;
                      }
                      if (line.trim()) {
                        return <p key={i} className="mb-3">{line}</p>;
                      }
                      return null;
                    })}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-dashed">
                <CardContent className="py-16 text-center">
                  <div className="p-4 rounded-full bg-muted w-fit mx-auto mb-4">
                    <BookOpen className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium mb-2">Select a Guide</h3>
                  <p className="text-sm text-muted-foreground">
                    Choose a topic from the left to view detailed instructions.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <div className="mt-12">
          <h2 className="font-semibold text-xl mb-6">Frequently Asked Questions</h2>
          <Card>
            <CardContent className="p-0">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`faq-${index}`} className="px-6">
                    <AccordionTrigger className="text-left" data-testid={`accordion-faq-${index}`}>
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
