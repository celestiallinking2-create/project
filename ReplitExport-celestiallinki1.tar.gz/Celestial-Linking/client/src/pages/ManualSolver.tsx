import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calculator,
  Play,
  Info,
  AlertCircle,
  Loader2,
  Grid3X3,
  FileText,
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function ManualSolver() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [title, setTitle] = useState("Custom Quantum Problem");
  const [inputMode, setInputMode] = useState<"matrix" | "equation">("matrix");
  const [matrixSize, setMatrixSize] = useState(3);
  const [matrixInput, setMatrixInput] = useState("");
  const [equationInput, setEquationInput] = useState("");
  const [quality, setQuality] = useState("medium");
  const [validationError, setValidationError] = useState<string | null>(null);

  const validateMatrix = (input: string): number[][] | null => {
    try {
      const rows = input.trim().split("\n").filter(r => r.trim());
      if (rows.length === 0) return null;
      
      const matrix = rows.map(row => {
        const values = row.trim().split(/[\s,]+/).map(v => {
          const num = parseFloat(v);
          if (isNaN(num)) throw new Error("Invalid number");
          return num;
        });
        return values;
      });
      
      const cols = matrix[0].length;
      if (!matrix.every(row => row.length === cols)) {
        throw new Error("Inconsistent row lengths");
      }
      
      if (matrix.length !== cols) {
        throw new Error("Matrix must be square");
      }
      
      return matrix;
    } catch (e) {
      return null;
    }
  };

  const handleMatrixChange = (value: string) => {
    setMatrixInput(value);
    if (value.trim()) {
      const matrix = validateMatrix(value);
      if (matrix) {
        setValidationError(null);
        setMatrixSize(matrix.length);
      } else {
        setValidationError("Invalid matrix format. Enter a square matrix with numbers separated by spaces or commas.");
      }
    } else {
      setValidationError(null);
    }
  };

  const runMutation = useMutation({
    mutationFn: async () => {
      let parameters: any = { quality };
      
      if (inputMode === "matrix") {
        const matrix = validateMatrix(matrixInput);
        if (!matrix) throw new Error("Invalid matrix");
        parameters.hamiltonian = matrix;
      } else {
        parameters.equation = equationInput;
      }
      
      const response = await apiRequest("POST", "/api/runs", {
        title,
        modelType: "custom-hamiltonian",
        parameters,
        quality,
      });
      return response;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/runs"] });
      toast({
        title: "Solver Started",
        description: "Your custom quantum problem is being solved.",
      });
      navigate(`/runs/${data.id}`);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to start solver. Please check your input.",
        variant: "destructive",
      });
    },
  });

  const canSubmit = inputMode === "matrix" 
    ? matrixInput.trim() && !validationError
    : equationInput.trim();

  const exampleMatrix = `1 0 0
0 2 0
0 0 3`;

  return (
    <div className="min-h-screen pt-16">
      <div className="bg-card/50 border-b py-8 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-quantum-cyan/20 to-soft-violet/20">
              <Calculator className="w-6 h-6 text-quantum-cyan" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold">Manual Equation Solver</h1>
              <p className="text-muted-foreground">
                Input custom Hamiltonians and quantum equations
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Problem Setup</CardTitle>
                <CardDescription>
                  Define your quantum system using a Hamiltonian matrix or equation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Problem Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter a descriptive title"
                    data-testid="input-solver-title"
                  />
                </div>

                <Tabs value={inputMode} onValueChange={(v) => setInputMode(v as "matrix" | "equation")}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="matrix" className="gap-2" data-testid="tab-matrix">
                      <Grid3X3 className="w-4 h-4" />
                      Matrix Input
                    </TabsTrigger>
                    <TabsTrigger value="equation" className="gap-2" data-testid="tab-equation">
                      <FileText className="w-4 h-4" />
                      Equation Input
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="matrix" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <Label>Hamiltonian Matrix</Label>
                        {matrixSize > 0 && !validationError && matrixInput.trim() && (
                          <Badge variant="secondary">
                            {matrixSize} x {matrixSize} matrix
                          </Badge>
                        )}
                      </div>
                      <Textarea
                        value={matrixInput}
                        onChange={(e) => handleMatrixChange(e.target.value)}
                        placeholder={exampleMatrix}
                        className="font-mono min-h-[160px]"
                        data-testid="textarea-matrix"
                      />
                      {validationError && (
                        <div className="flex items-center gap-2 text-destructive text-sm">
                          <AlertCircle className="w-4 h-4" />
                          {validationError}
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground">
                        Enter a square matrix with values separated by spaces or commas. Each row on a new line.
                      </p>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="equation" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Quantum Equation</Label>
                      <Textarea
                        value={equationInput}
                        onChange={(e) => setEquationInput(e.target.value)}
                        placeholder="H = -ℏ²/2m ∇² + V(x)"
                        className="font-mono min-h-[160px]"
                        data-testid="textarea-equation"
                      />
                      <p className="text-xs text-muted-foreground">
                        Enter your quantum equation in standard notation. Supports Hamiltonian operators.
                      </p>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="space-y-4">
                  <h4 className="font-medium text-sm">Solver Quality</h4>
                  <RadioGroup
                    value={quality}
                    onValueChange={setQuality}
                    className="flex flex-col gap-3"
                  >
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="basic" id="basic" />
                      <Label htmlFor="basic" className="cursor-pointer">
                        <span className="font-medium">Basic</span>
                        <span className="text-muted-foreground text-sm ml-2">
                          Fast, suitable for small matrices
                        </span>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="cursor-pointer">
                        <span className="font-medium">Medium</span>
                        <span className="text-muted-foreground text-sm ml-2">
                          Balanced precision
                        </span>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value="high" id="high" />
                      <Label htmlFor="high" className="cursor-pointer">
                        <span className="font-medium">High</span>
                        <span className="text-muted-foreground text-sm ml-2">
                          Maximum accuracy
                        </span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            <Button
              size="lg"
              className="w-full bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90"
              onClick={() => runMutation.mutate()}
              disabled={runMutation.isPending || !canSubmit}
              data-testid="button-solve"
            >
              {runMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Solving...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" />
                  Solve Equation
                </>
              )}
            </Button>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Supported Equations
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-4">
                <div>
                  <h4 className="font-medium mb-1">Eigenvalue Problems</h4>
                  <p className="text-muted-foreground">
                    Solve Hψ = Eψ for eigenvalues and eigenvectors
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-1">Hamiltonian Matrices</h4>
                  <p className="text-muted-foreground">
                    Input custom Hamiltonians for diagonalization
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-1">Quantum Operators</h4>
                  <p className="text-muted-foreground">
                    Define operators using matrix representation
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Output Format</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-2 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-quantum-cyan" />
                    Eigenvalues (sorted)
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-soft-violet" />
                    Eigenvectors (normalized)
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    Probability distributions
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-amber-500" />
                    CSV/JSON export
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-dashed bg-muted/20">
              <CardContent className="pt-6">
                <h4 className="font-medium mb-2 text-sm">Example Matrix</h4>
                <pre className="text-xs font-mono bg-background p-3 rounded-lg overflow-x-auto">
{`1  0  0.5
0  2  0
0.5 0  3`}
                </pre>
                <p className="text-xs text-muted-foreground mt-2">
                  Hermitian matrix representing a coupled 3-level system
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
