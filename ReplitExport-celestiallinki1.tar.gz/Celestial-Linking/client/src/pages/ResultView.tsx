import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ChevronLeft,
  Download,
  FileJson,
  FileSpreadsheet,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Settings,
  Atom,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Run, Result } from "@shared/schema";
import {
  EnergyLevelChart,
  ProbabilityChart,
  WavefunctionChart,
  generateSampleEnergyData,
  generateSampleProbabilityData,
  generateSampleWavefunctionData,
} from "@/components/QuantumCharts";

const statusIcons = {
  completed: CheckCircle2,
  running: Loader2,
  pending: Clock,
  failed: XCircle,
};

const statusColors = {
  completed: "bg-green-500/10 text-green-600 dark:text-green-400",
  running: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  pending: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
  failed: "bg-red-500/10 text-red-600 dark:text-red-400",
};

export default function ResultView() {
  const { id } = useParams<{ id: string }>();

  const { data: run, isLoading: runLoading } = useQuery<Run>({
    queryKey: ["/api/runs", id],
  });

  const { data: result, isLoading: resultLoading } = useQuery<Result>({
    queryKey: ["/api/results", id],
    enabled: run?.status === "completed",
  });

  const handleExportCSV = () => {
    if (!result) return;
    
    const eigenvalues = result.eigenvalues as number[];
    let csv = "Level,Eigenvalue\n";
    eigenvalues.forEach((val, i) => {
      csv += `${i + 1},${val}\n`;
    });
    
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${run?.title || "result"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJSON = () => {
    if (!result) return;
    
    const data = {
      run: {
        id: run?.id,
        title: run?.title,
        modelType: run?.modelType,
        parameters: run?.parameters,
        quality: run?.quality,
        runtime: run?.runtime,
      },
      result: {
        eigenvalues: result.eigenvalues,
        eigenvectors: result.eigenvectors,
        probabilities: result.probabilities,
      },
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${run?.title || "result"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (runLoading) {
    return (
      <div className="min-h-screen pt-16">
        <div className="bg-card/50 border-b py-8 px-6">
          <div className="max-w-7xl mx-auto">
            <Skeleton className="h-8 w-48 mb-4" />
            <Skeleton className="h-10 w-96" />
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="h-64 lg:col-span-2" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  if (!run) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <div className="p-4 rounded-full bg-muted w-fit mx-auto mb-4">
              <Atom className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Run Not Found</h2>
            <p className="text-muted-foreground mb-4">
              The run you're looking for doesn't exist or has been deleted.
            </p>
            <Link href="/runs">
              <Button>Back to My Runs</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const StatusIcon = statusIcons[run.status as keyof typeof statusIcons] || Clock;
  const statusColor = statusColors[run.status as keyof typeof statusColors] || statusColors.pending;
  const params = run.parameters as Record<string, any>;
  const eigenvalues = (result?.eigenvalues as number[]) || [];
  const eigenvectors = (result?.eigenvectors as number[][]) || [];

  const energyData = eigenvalues.length > 0 
    ? eigenvalues.map((e, i) => ({ level: `n=${i + 1}`, energy: e }))
    : generateSampleEnergyData(5);
  
  const probabilityData = generateSampleProbabilityData(100, 1);
  const wavefunctionData = generateSampleWavefunctionData(100, 1);

  return (
    <div className="min-h-screen pt-16">
      <div className="bg-card/50 border-b py-6 px-6">
        <div className="max-w-7xl mx-auto">
          <Link href="/runs">
            <Button variant="ghost" size="sm" className="mb-4" data-testid="button-back-to-runs">
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back to My Runs
            </Button>
          </Link>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-start gap-4 flex-wrap">
              <div className="p-3 rounded-xl bg-gradient-to-br from-quantum-cyan/20 to-soft-violet/20">
                <Atom className="w-6 h-6 text-quantum-cyan" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-1 flex-wrap">
                  <h1 className="text-xl font-semibold" data-testid="text-run-title">{run.title}</h1>
                  <Badge variant="secondary" className={statusColor}>
                    <StatusIcon className={`w-3 h-3 mr-1 ${run.status === "running" ? "animate-spin" : ""}`} />
                    {run.status}
                  </Badge>
                </div>
                <p className="text-muted-foreground text-sm">
                  {run.modelType.replace(/-/g, " ")} | {run.quality} quality
                </p>
              </div>
            </div>
            {run.status === "completed" && (
              <div className="flex gap-2 flex-wrap">
                <Button variant="outline" size="sm" onClick={handleExportCSV} data-testid="button-export-csv">
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Export CSV
                </Button>
                <Button variant="outline" size="sm" onClick={handleExportJSON} data-testid="button-export-json">
                  <FileJson className="w-4 h-4 mr-2" />
                  Export JSON
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Parameters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-2 text-sm">
                {Object.entries(params).map(([key, value]) => (
                  <div key={key} className="flex justify-between gap-2">
                    <dt className="text-muted-foreground">{key.replace(/([A-Z])/g, " $1").trim()}</dt>
                    <dd className="font-mono">{String(value)}</dd>
                  </div>
                ))}
              </dl>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Run Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between gap-2">
                  <dt className="text-muted-foreground">Runtime</dt>
                  <dd className="font-mono">{run.runtime ? `${run.runtime}ms` : "—"}</dd>
                </div>
                <div className="flex justify-between gap-2">
                  <dt className="text-muted-foreground">Quality</dt>
                  <dd className="capitalize">{run.quality}</dd>
                </div>
                <div className="flex justify-between gap-2">
                  <dt className="text-muted-foreground">Created</dt>
                  <dd>{run.createdAt ? new Date(run.createdAt).toLocaleDateString() : "—"}</dd>
                </div>
              </dl>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Download className="w-4 h-4" />
                Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {result?.summary || `Solved ${run.modelType.replace(/-/g, " ")} with ${run.quality} precision. ${eigenvalues.length > 0 ? `Found ${eigenvalues.length} eigenvalues.` : "Processing..."}`}
              </p>
            </CardContent>
          </Card>
        </div>

        {run.status === "completed" && eigenvalues.length > 0 && (
          <>
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="text-lg">Eigenvalues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Level</TableHead>
                        <TableHead>Energy (eV)</TableHead>
                        <TableHead>Difference</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {eigenvalues.slice(0, 10).map((val, i) => (
                        <TableRow key={i} data-testid={`row-eigenvalue-${i}`}>
                          <TableCell className="font-medium">n = {i + 1}</TableCell>
                          <TableCell className="font-mono">{val.toFixed(6)}</TableCell>
                          <TableCell className="font-mono text-muted-foreground">
                            {i > 0 ? `+${(val - eigenvalues[i - 1]).toFixed(6)}` : "—"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <EnergyLevelChart title="Energy Level Diagram" data={energyData} />
              <ProbabilityChart title="Probability Density |ψ|²" data={probabilityData} />
            </div>

            <WavefunctionChart title="Wavefunction ψ(x)" data={wavefunctionData} className="mb-8" />
          </>
        )}

        {run.status === "running" && (
          <Card>
            <CardContent className="py-16 text-center">
              <Loader2 className="w-12 h-12 animate-spin text-quantum-cyan mx-auto mb-4" />
              <h3 className="font-medium mb-2">Solving in Progress</h3>
              <p className="text-sm text-muted-foreground">
                Your quantum problem is being solved. This may take a few moments.
              </p>
            </CardContent>
          </Card>
        )}

        {run.status === "pending" && (
          <Card>
            <CardContent className="py-16 text-center">
              <Clock className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="font-medium mb-2">Pending</h3>
              <p className="text-sm text-muted-foreground">
                Your run is queued and will start shortly.
              </p>
            </CardContent>
          </Card>
        )}

        {run.status === "failed" && (
          <Card className="border-destructive/50">
            <CardContent className="py-16 text-center">
              <XCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h3 className="font-medium mb-2">Solver Failed</h3>
              <p className="text-sm text-muted-foreground mb-4">
                There was an error processing your quantum problem.
              </p>
              <Link href="/library">
                <Button variant="outline">Try Again</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
