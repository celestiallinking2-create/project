import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { QuantumWaves, ParticleField } from "@/components/QuantumWaves";
import { Atom, Calculator, Library, Shield, Zap, LineChart, ArrowRight } from "lucide-react";

const features = [
  {
    icon: Calculator,
    title: "Manual Equation Solver",
    description: "Input custom Hamiltonians and solve eigenvalue problems with step-by-step summaries.",
  },
  {
    icon: Library,
    title: "Quantum Model Library",
    description: "Explore pre-built models from particle-in-a-box to spin systems with interactive parameters.",
  },
  {
    icon: LineChart,
    title: "Interactive Visualizations",
    description: "Visualize energy levels, probability distributions, and wavefunctions with elegant charts.",
  },
  {
    icon: Shield,
    title: "Persistent Workspace",
    description: "Save your problems and results. Resume your work anytime with secure cloud storage.",
  },
  {
    icon: Zap,
    title: "Lightweight & Fast",
    description: "Optimized computations that run smoothly on any device without heavy resource usage.",
  },
  {
    icon: Atom,
    title: "Scientific Accuracy",
    description: "Rigorous quantum mechanics calculations using proven numerical methods.",
  },
];

const steps = [
  { number: 1, title: "Choose a Model", description: "Select from our quantum library or create a custom equation" },
  { number: 2, title: "Set Parameters", description: "Configure system properties like mass, potential, and boundaries" },
  { number: 3, title: "Run Solver", description: "Execute the quantum solver with your chosen quality settings" },
  { number: 4, title: "Analyze Results", description: "Visualize eigenvalues, wavefunctions, and export your data" },
];

export default function Landing() {
  return (
    <div className="min-h-screen">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-deep-space-gradient">
        <QuantumWaves variant="hero" />
        <ParticleField />
        
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/40" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center py-24">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-8">
            <Atom className="w-4 h-4 text-quantum-cyan" />
            <span className="text-sm text-white/90">Professional Quantum Mechanics Platform</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Where{" "}
            <span className="bg-gradient-to-r from-quantum-cyan to-soft-violet bg-clip-text text-transparent">
              Quantum Physics
            </span>
            <br />
            Meets the Cosmos
          </h1>
          
          <p className="text-lg sm:text-xl text-white/80 mb-10 max-w-2xl mx-auto">
            Solve, simulate, and visualize quantum mechanics problems with clarity and efficiency. 
            A professional-grade educational and research tool that runs entirely in your browser.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              asChild
              size="lg"
              className="bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90 font-semibold px-8 min-h-12 text-base"
              data-testid="button-get-started"
            >
              <a href="/api/login">
                Get Started Free
                <ArrowRight className="w-5 h-5 ml-2" />
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm min-h-12 text-base"
              data-testid="button-explore-library"
            >
              <a href="/api/login">
                <Library className="w-5 h-5 mr-2" />
                Explore Quantum Library
              </a>
            </Button>
          </div>
        </div>
        
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-2">
            <div className="w-1.5 h-3 rounded-full bg-white/50" />
          </div>
        </div>
      </section>

      <section className="py-24 bg-background relative">
        <QuantumWaves variant="subtle" />
        <div className="max-w-3xl mx-auto px-6 text-center relative z-10">
          <h2 className="text-3xl sm:text-4xl font-semibold mb-6">
            Quantum Mechanics Made{" "}
            <span className="text-quantum-cyan">Accessible</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Celestial Linking transforms complex quantum calculations into an intuitive, 
            visually stunning experience. Whether you're a student exploring quantum concepts 
            or a researcher analyzing custom Hamiltonians, our platform delivers professional 
            results with minimal complexity.
          </p>
        </div>
      </section>

      <section className="py-24 bg-card/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-semibold mb-4">
              Powerful Features for{" "}
              <span className="text-soft-violet">Quantum Exploration</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to solve, visualize, and understand quantum mechanics problems.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className="group hover:shadow-lg transition-all duration-300"
                data-testid={`card-feature-${index}`}
              >
                <CardContent className="p-6">
                  <div className="p-3 rounded-lg bg-gradient-to-br from-quantum-cyan/10 to-soft-violet/10 w-fit mb-4 group-hover:scale-110 transition-transform duration-300">
                    <feature.icon className="w-6 h-6 text-quantum-cyan" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-semibold mb-4">
              Simple <span className="text-quantum-cyan">Workflow</span>
            </h2>
            <p className="text-muted-foreground">
              Get from problem to solution in four easy steps.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div 
                key={index} 
                className="relative text-center"
                data-testid={`step-${step.number}`}
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-quantum-cyan to-soft-violet flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                  {step.number}
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-quantum-cyan/50 to-soft-violet/50" />
                )}
                <h3 className="font-semibold mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-deep-space-gradient relative overflow-hidden">
        <ParticleField />
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
          <h2 className="text-3xl sm:text-4xl font-semibold text-white mb-6">
            Ready to Explore the{" "}
            <span className="text-quantum-cyan">Quantum Realm</span>?
          </h2>
          <p className="text-lg text-white/80 mb-10 max-w-2xl mx-auto">
            Join researchers, students, and educators who trust Celestial Linking 
            for their quantum mechanics calculations.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-quantum-cyan text-deep-space hover:bg-quantum-cyan/90 font-semibold px-10 min-h-12"
            data-testid="button-cta-signup"
          >
            <a href="/api/login">
              Start Your Journey
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </Button>
        </div>
      </section>

      <footer className="py-12 bg-deep-space-gradient border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <Atom className="w-6 h-6 text-quantum-cyan" />
              <span className="text-white font-semibold">Celestial Linking</span>
            </div>
            <p className="text-white/60 text-sm">
              Where Quantum Physics Meets the Cosmos
            </p>
            <p className="text-white/40 text-sm">
              Crafted with precision for the scientific community
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
