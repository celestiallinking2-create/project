import { sql, relations } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  real,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Quantum problems/equations saved by users
export const problems = pgTable("problems", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  modelType: varchar("model_type", { length: 100 }).notNull(),
  parameters: jsonb("parameters").notNull().default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Solver runs
export const runs = pgTable("runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  problemId: varchar("problem_id").references(() => problems.id, { onDelete: "set null" }),
  title: varchar("title", { length: 255 }).notNull(),
  modelType: varchar("model_type", { length: 100 }).notNull(),
  parameters: jsonb("parameters").notNull().default({}),
  quality: varchar("quality", { length: 20 }).notNull().default("medium"),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  runtime: integer("runtime"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Results from solver runs
export const results = pgTable("results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  runId: varchar("run_id").notNull().references(() => runs.id, { onDelete: "cascade" }),
  eigenvalues: jsonb("eigenvalues").notNull().default([]),
  eigenvectors: jsonb("eigenvectors").notNull().default([]),
  probabilities: jsonb("probabilities").notNull().default([]),
  wavefunctions: jsonb("wavefunctions").notNull().default([]),
  summary: text("summary"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  problems: many(problems),
  runs: many(runs),
}));

export const problemsRelations = relations(problems, ({ one, many }) => ({
  user: one(users, {
    fields: [problems.userId],
    references: [users.id],
  }),
  runs: many(runs),
}));

export const runsRelations = relations(runs, ({ one }) => ({
  user: one(users, {
    fields: [runs.userId],
    references: [users.id],
  }),
  problem: one(problems, {
    fields: [runs.problemId],
    references: [problems.id],
  }),
  result: one(results, {
    fields: [runs.id],
    references: [results.runId],
  }),
}));

export const resultsRelations = relations(results, ({ one }) => ({
  run: one(runs, {
    fields: [results.runId],
    references: [runs.id],
  }),
}));

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertProblem = typeof problems.$inferInsert;
export type Problem = typeof problems.$inferSelect;

export type InsertRun = typeof runs.$inferInsert;
export type Run = typeof runs.$inferSelect;

export type InsertResult = typeof results.$inferInsert;
export type Result = typeof results.$inferSelect;

// Zod schemas for validation
export const insertProblemSchema = createInsertSchema(problems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRunSchema = createInsertSchema(runs).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertResultSchema = createInsertSchema(results).omit({
  id: true,
  createdAt: true,
});

// Quantum model types
export const quantumModels = [
  "particle-in-box",
  "harmonic-oscillator",
  "finite-well",
  "spin-half",
  "custom-hamiltonian",
] as const;

export type QuantumModelType = typeof quantumModels[number];
