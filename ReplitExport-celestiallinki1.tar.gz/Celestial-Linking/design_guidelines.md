# Celestial Linking - Design Guidelines (Compacted)

## Design Foundation

**Approach**: Custom celestial theme with Material Design component behavior
**Principles**: Scientific clarity, lightweight elegance, professional credibility, functional immersion

---

## Visual Design

### Color System
**Primary Palette**:
- Deep Space Blue: `#0A1628` (backgrounds, nav, headers)
- Quantum Cyan: `#00D9FF` (CTAs, active states, highlights)
- Soft Violet: `#9D7CFF` (accents, data viz)
- Clean White: `#FFFFFF` (content backgrounds)

**Functional Colors**:
- Slate Gray `#64748B` (secondary text, borders)
- Success `#10B981` | Warning `#F59E0B` | Error `#EF4444`

**Backgrounds**:
- Primary: White + 5% quantum wave overlay
- Nav/header: Deep Space Blue gradient
- Cards: White, soft shadow, violet-cyan border glow on hover

### Typography
**Fonts**: Inter (primary), JetBrains Mono (code/equations)

**Scale**:
- Hero: `text-6xl font-bold`
- Sections: `text-4xl font-semibold`
- Page titles: `text-2xl font-semibold`
- Cards: `text-xl font-medium`
- Body: `text-base font-normal`
- Labels: `text-xs font-medium uppercase tracking-wide`

**Colors**: Headers in Deep Space Blue or Cyan→Violet gradient, body `#334155`, equations in monospace with Cyan highlights

### Layout
**Spacing**: Use 2, 4, 6, 8, 12, 16, 24 (Tailwind units)
- Components: `p-4` to `p-6`
- Sections: `py-12` to `py-24`
- Forms: `space-y-4`

**Containers**:
- Full-width: `w-full max-w-7xl mx-auto px-6`
- Content: `max-w-6xl` | Forms: `max-w-3xl` | Narrow: `max-w-2xl`

**Grids**:
- Library cards: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3`
- Problem builder: `lg:grid-cols-2` (params left, preview right)

---

## Components

### Navigation
- Fixed header, `h-16`, Deep Space Blue, subtle shadow
- Logo left, nav center, user menu right (circular avatar, dropdown)
- Items: Home, Quantum Library, Manual Solver, My Runs, Help

### Buttons
**Primary**: `bg-cyan-500 text-white rounded-lg px-6 py-3 font-medium shadow-md hover:bg-cyan-600 active:scale-95`
**Secondary**: Same with `bg-violet-500`
**Outline**: `border-2 border-cyan-500 backdrop-blur-sm hover:bg-cyan-500`

### Cards
**Standard**: `bg-white rounded-xl shadow-lg p-6 border border-slate-200`
**Model Card**: Add `hover:scale-105 hover:shadow-xl` + border glow, icon top, "Explore" button bottom
**Run Card**: Horizontal layout, status dot, title, date, runtime, status badge, clickable

### Forms
**Input**: `border-2 border-slate-300 rounded-lg px-4 py-2 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200`
**Labels**: `text-sm font-medium text-slate-700 mb-2`
**Validation**: Error `border-red-500`, Success `border-green-500`, helper `text-xs text-slate-500`

### Problem Builder
**Left**: Title input, model selector, parameter groups, quality radio (Basic/Medium/High), "Run Solver" (large Cyan)
**Right**: Preview card, resource indicator, parameter summary

### Charts (Chart.js)
- Energy levels: Horizontal bars (Violet)
- Probability: Line charts (Cyan fill)
- Wavefunctions: Area charts (Cyan→Violet gradient)
- Styling: White background, subtle grid, `slate-700` labels, rounded tooltips with backdrop blur

### Tables
- Full-width responsive, Deep Space Blue header (white text)
- Alternating rows (`white`/`slate-50`), hover `bg-cyan-50`
- Status badges, icon buttons (view, delete)

### Results View
Sections: Summary card → Parameters grid → Outputs (eigenvalues table + eigenvectors) → Charts (stacked, `py-8`) → Export buttons (CSV, JSON)

### Modals
`backdrop-blur-md` dark overlay, white dialog `rounded-xl max-w-2xl shadow-2xl p-8`, header with `border-b`, footer with Cancel (outline) + Confirm (Cyan)

---

## Page Layouts

### Home
1. **Hero**: Full viewport, Deep Space Blue gradient, quantum wave animation, centered `max-w-4xl`, gradient headline, 2×2 CTA grid (stack mobile)
2. **Mission**: `max-w-3xl py-24` centered text
3. **Capabilities**: 3-column feature grid with icons
4. **Examples**: 2-column sample plots
5. **Quick Start**: Numbered step cards
6. **Footer**: Deep Space Blue, links

### Quantum Library
Header + search/filter → 3-column model cards → Detail view: breadcrumb, explanation, interactive form, preview, "Run This Model"

### Manual Solver
`max-w-4xl`: Title, equation input (textarea/matrix builder), solver options, submit, results area

### My Runs
Header + filters (All/Completed/Running/Failed) → sorted table → pagination → empty state CTA

### Help
Sidebar nav (sticky) + content area (article-style), Next/Prev buttons

---

## Visual Effects

### Quantum Elements
- SVG wave patterns: 5-10% opacity, CSS keyframe animation (20s), flowing sine waves
- Particle clouds: Cyan/violet dots, varying opacity
- Gradients: Deep Space Blue backgrounds, Cyan→Violet text/borders

### Transitions (Minimal)
- Buttons: `200ms ease`
- Cards: `300ms ease-in-out`
- Validation: `150ms`
- Avoid: Parallax, scroll animations, particle systems

---

## Responsive Design

**Breakpoints**: sm(640), md(768), lg(1024), xl(1280)

**Mobile**:
- Hamburger nav
- Stack CTAs/grids vertically
- Scrollable tables or card-based
- Reduce padding: `py-24→py-12`, `px-6→px-4`

**Tablet**: 2-column grids, full nav visible

---

## Accessibility & Performance

**Accessibility**:
- Min touch target: `h-11` (44px)
- WCAG AA contrast: 4.5:1 text
- Labels + aria-labels on inputs
- Keyboard nav with `ring-2 ring-cyan-500` focus states
- Chart text alternatives

**Performance**:
- Animations: CSS transforms/opacity only
- CSS gradients (not images)
- Lazy load/virtualize charts for large datasets
- Progressive image loading
- Debounce equation validation

---

## Image Assets

**Hero**: Abstract quantum visualization (particle probability clouds, wave interference, Cyan/Violet on Deep Space Blue)
**Icons**: Three small illustrations (solver accuracy, visualization clarity, data persistence)
**Examples**: 2-3 Chart.js energy/wavefunction plots

All images maintain celestial palette with scientific aesthetic.